//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2022.1 (win64) Build 3526262 Mon Apr 18 15:48:16 MDT 2022
//Date        : Mon Oct  5 19:49:05 2026
//Host        : 1850-B302S106 running 64-bit major release  (build 9200)
//Command     : generate_target nand_gate_design_wrapper.bd
//Design      : nand_gate_design_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module nand_gate_design_wrapper
   ();


  nand_gate_design nand_gate_design_i
       ();
endmodule
