###############################################################################################################
# Core-Level Timing Constraints for axi_dwidth_converter Component "nand_gate_design_auto_ds_0"
###############################################################################################################
#
# This component is not configured to perform asynchronous clock-domain-crossing.
# No timing core-level constraints are needed.
# (Synchronous clock-domain-crossings, if any, remain covered by your system-level PERIOD constraints.)
