onbreak {quit -f}
onerror {quit -f}

vsim -lib xil_defaultlib nand_gate_design_opt

set NumericStdNoWarnings 1
set StdArithNoWarnings 1

do {wave.do}

view wave
view structure
view signals

do {nand_gate_design.udo}

run -all

quit -force
