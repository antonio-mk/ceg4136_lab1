-makelib xcelium_lib/xilinx_vip -sv \
  "N:/Xilinx/Vivado/2022.1/data/xilinx_vip/hdl/axi4stream_vip_axi4streampc.sv" \
  "N:/Xilinx/Vivado/2022.1/data/xilinx_vip/hdl/axi_vip_axi4pc.sv" \
  "N:/Xilinx/Vivado/2022.1/data/xilinx_vip/hdl/xil_common_vip_pkg.sv" \
  "N:/Xilinx/Vivado/2022.1/data/xilinx_vip/hdl/axi4stream_vip_pkg.sv" \
  "N:/Xilinx/Vivado/2022.1/data/xilinx_vip/hdl/axi_vip_pkg.sv" \
  "N:/Xilinx/Vivado/2022.1/data/xilinx_vip/hdl/axi4stream_vip_if.sv" \
  "N:/Xilinx/Vivado/2022.1/data/xilinx_vip/hdl/axi_vip_if.sv" \
  "N:/Xilinx/Vivado/2022.1/data/xilinx_vip/hdl/clk_vip_if.sv" \
  "N:/Xilinx/Vivado/2022.1/data/xilinx_vip/hdl/rst_vip_if.sv" \
-endlib
-makelib xcelium_lib/axi_infrastructure_v1_1_0 \
  "../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/ec67/hdl/axi_infrastructure_v1_1_vl_rfs.v" \
-endlib
-makelib xcelium_lib/axi_vip_v1_1_12 -sv \
  "../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/1033/hdl/axi_vip_v1_1_vl_rfs.sv" \
-endlib
-makelib xcelium_lib/zynq_ultra_ps_e_vip_v1_0_12 -sv \
  "../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/8cdf/hdl/zynq_ultra_ps_e_vip_v1_0_vl_rfs.sv" \
-endlib
-makelib xcelium_lib/xil_defaultlib \
  "../../../bd/nand_gate_design/ip/nand_gate_design_zynq_ultra_ps_e_0_0/sim/nand_gate_design_zynq_ultra_ps_e_0_0_vip_wrapper.v" \
-endlib
-makelib xcelium_lib/lib_cdc_v1_0_2 \
  "../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/ef1e/hdl/lib_cdc_v1_0_rfs.vhd" \
-endlib
-makelib xcelium_lib/proc_sys_reset_v5_0_13 \
  "../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/8842/hdl/proc_sys_reset_v5_0_vh_rfs.vhd" \
-endlib
-makelib xcelium_lib/xil_defaultlib \
  "../../../bd/nand_gate_design/ip/nand_gate_design_proc_sys_reset_0_0/sim/nand_gate_design_proc_sys_reset_0_0.vhd" \
-endlib
-makelib xcelium_lib/axi_lite_ipif_v3_0_4 \
  "../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/66ea/hdl/axi_lite_ipif_v3_0_vh_rfs.vhd" \
-endlib
-makelib xcelium_lib/interrupt_control_v3_1_4 \
  "../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/a040/hdl/interrupt_control_v3_1_vh_rfs.vhd" \
-endlib
-makelib xcelium_lib/axi_gpio_v2_0_28 \
  "../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/3ed9/hdl/axi_gpio_v2_0_vh_rfs.vhd" \
-endlib
-makelib xcelium_lib/xil_defaultlib \
  "../../../bd/nand_gate_design/ip/nand_gate_design_axi_gpio_0_0/sim/nand_gate_design_axi_gpio_0_0.vhd" \
  "../../../bd/nand_gate_design/ip/nand_gate_design_axi_gpio_1_0/sim/nand_gate_design_axi_gpio_1_0.vhd" \
-endlib
-makelib xcelium_lib/xil_defaultlib \
  "../../../bd/nand_gate_design/ip/nand_gate_design_nand_gate_0_0/sim/nand_gate_design_nand_gate_0_0.v" \
-endlib
-makelib xcelium_lib/generic_baseblocks_v2_1_0 \
  "../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/b752/hdl/generic_baseblocks_v2_1_vl_rfs.v" \
-endlib
-makelib xcelium_lib/axi_register_slice_v2_1_26 \
  "../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/0a3f/hdl/axi_register_slice_v2_1_vl_rfs.v" \
-endlib
-makelib xcelium_lib/fifo_generator_v13_2_7 \
  "../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/83df/simulation/fifo_generator_vlog_beh.v" \
-endlib
-makelib xcelium_lib/fifo_generator_v13_2_7 \
  "../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/83df/hdl/fifo_generator_v13_2_rfs.vhd" \
-endlib
-makelib xcelium_lib/fifo_generator_v13_2_7 \
  "../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/83df/hdl/fifo_generator_v13_2_rfs.v" \
-endlib
-makelib xcelium_lib/axi_data_fifo_v2_1_25 \
  "../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/5390/hdl/axi_data_fifo_v2_1_vl_rfs.v" \
-endlib
-makelib xcelium_lib/axi_crossbar_v2_1_27 \
  "../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/3fa0/hdl/axi_crossbar_v2_1_vl_rfs.v" \
-endlib
-makelib xcelium_lib/xil_defaultlib \
  "../../../bd/nand_gate_design/ip/nand_gate_design_xbar_0/sim/nand_gate_design_xbar_0.v" \
-endlib
-makelib xcelium_lib/axi_protocol_converter_v2_1_26 \
  "../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/90c8/hdl/axi_protocol_converter_v2_1_vl_rfs.v" \
-endlib
-makelib xcelium_lib/axi_clock_converter_v2_1_25 \
  "../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/e893/hdl/axi_clock_converter_v2_1_vl_rfs.v" \
-endlib
-makelib xcelium_lib/blk_mem_gen_v8_4_5 \
  "../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/25a8/simulation/blk_mem_gen_v8_4.v" \
-endlib
-makelib xcelium_lib/axi_dwidth_converter_v2_1_26 \
  "../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/b3c7/hdl/axi_dwidth_converter_v2_1_vl_rfs.v" \
-endlib
-makelib xcelium_lib/xil_defaultlib \
  "../../../bd/nand_gate_design/ip/nand_gate_design_auto_ds_0/sim/nand_gate_design_auto_ds_0.v" \
  "../../../bd/nand_gate_design/ip/nand_gate_design_auto_pc_0/sim/nand_gate_design_auto_pc_0.v" \
  "../../../bd/nand_gate_design/ip/nand_gate_design_auto_ds_1/sim/nand_gate_design_auto_ds_1.v" \
  "../../../bd/nand_gate_design/ip/nand_gate_design_auto_pc_1/sim/nand_gate_design_auto_pc_1.v" \
  "../../../bd/nand_gate_design/sim/nand_gate_design.v" \
-endlib
-makelib xcelium_lib/xil_defaultlib \
  glbl.v
-endlib

