vlib work
vlib riviera

vlib riviera/xilinx_vip
vlib riviera/axi_infrastructure_v1_1_0
vlib riviera/axi_vip_v1_1_12
vlib riviera/zynq_ultra_ps_e_vip_v1_0_12
vlib riviera/xil_defaultlib
vlib riviera/lib_cdc_v1_0_2
vlib riviera/proc_sys_reset_v5_0_13
vlib riviera/axi_lite_ipif_v3_0_4
vlib riviera/interrupt_control_v3_1_4
vlib riviera/axi_gpio_v2_0_28
vlib riviera/generic_baseblocks_v2_1_0
vlib riviera/axi_register_slice_v2_1_26
vlib riviera/fifo_generator_v13_2_7
vlib riviera/axi_data_fifo_v2_1_25
vlib riviera/axi_crossbar_v2_1_27
vlib riviera/axi_protocol_converter_v2_1_26
vlib riviera/axi_clock_converter_v2_1_25
vlib riviera/blk_mem_gen_v8_4_5
vlib riviera/axi_dwidth_converter_v2_1_26

vmap xilinx_vip riviera/xilinx_vip
vmap axi_infrastructure_v1_1_0 riviera/axi_infrastructure_v1_1_0
vmap axi_vip_v1_1_12 riviera/axi_vip_v1_1_12
vmap zynq_ultra_ps_e_vip_v1_0_12 riviera/zynq_ultra_ps_e_vip_v1_0_12
vmap xil_defaultlib riviera/xil_defaultlib
vmap lib_cdc_v1_0_2 riviera/lib_cdc_v1_0_2
vmap proc_sys_reset_v5_0_13 riviera/proc_sys_reset_v5_0_13
vmap axi_lite_ipif_v3_0_4 riviera/axi_lite_ipif_v3_0_4
vmap interrupt_control_v3_1_4 riviera/interrupt_control_v3_1_4
vmap axi_gpio_v2_0_28 riviera/axi_gpio_v2_0_28
vmap generic_baseblocks_v2_1_0 riviera/generic_baseblocks_v2_1_0
vmap axi_register_slice_v2_1_26 riviera/axi_register_slice_v2_1_26
vmap fifo_generator_v13_2_7 riviera/fifo_generator_v13_2_7
vmap axi_data_fifo_v2_1_25 riviera/axi_data_fifo_v2_1_25
vmap axi_crossbar_v2_1_27 riviera/axi_crossbar_v2_1_27
vmap axi_protocol_converter_v2_1_26 riviera/axi_protocol_converter_v2_1_26
vmap axi_clock_converter_v2_1_25 riviera/axi_clock_converter_v2_1_25
vmap blk_mem_gen_v8_4_5 riviera/blk_mem_gen_v8_4_5
vmap axi_dwidth_converter_v2_1_26 riviera/axi_dwidth_converter_v2_1_26

vlog -work xilinx_vip  -sv2k12 "+incdir+N:/Xilinx/Vivado/2022.1/data/xilinx_vip/include" \
"N:/Xilinx/Vivado/2022.1/data/xilinx_vip/hdl/axi4stream_vip_axi4streampc.sv" \
"N:/Xilinx/Vivado/2022.1/data/xilinx_vip/hdl/axi_vip_axi4pc.sv" \
"N:/Xilinx/Vivado/2022.1/data/xilinx_vip/hdl/xil_common_vip_pkg.sv" \
"N:/Xilinx/Vivado/2022.1/data/xilinx_vip/hdl/axi4stream_vip_pkg.sv" \
"N:/Xilinx/Vivado/2022.1/data/xilinx_vip/hdl/axi_vip_pkg.sv" \
"N:/Xilinx/Vivado/2022.1/data/xilinx_vip/hdl/axi4stream_vip_if.sv" \
"N:/Xilinx/Vivado/2022.1/data/xilinx_vip/hdl/axi_vip_if.sv" \
"N:/Xilinx/Vivado/2022.1/data/xilinx_vip/hdl/clk_vip_if.sv" \
"N:/Xilinx/Vivado/2022.1/data/xilinx_vip/hdl/rst_vip_if.sv" \

vlog -work axi_infrastructure_v1_1_0  -v2k5 "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/ec67/hdl" "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/8cdf/hdl" "+incdir+N:/Xilinx/Vivado/2022.1/data/xilinx_vip/include" \
"../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/ec67/hdl/axi_infrastructure_v1_1_vl_rfs.v" \

vlog -work axi_vip_v1_1_12  -sv2k12 "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/ec67/hdl" "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/8cdf/hdl" "+incdir+N:/Xilinx/Vivado/2022.1/data/xilinx_vip/include" \
"../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/1033/hdl/axi_vip_v1_1_vl_rfs.sv" \

vlog -work zynq_ultra_ps_e_vip_v1_0_12  -sv2k12 "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/ec67/hdl" "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/8cdf/hdl" "+incdir+N:/Xilinx/Vivado/2022.1/data/xilinx_vip/include" \
"../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/8cdf/hdl/zynq_ultra_ps_e_vip_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib  -v2k5 "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/ec67/hdl" "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/8cdf/hdl" "+incdir+N:/Xilinx/Vivado/2022.1/data/xilinx_vip/include" \
"../../../bd/nand_gate_design/ip/nand_gate_design_zynq_ultra_ps_e_0_0/sim/nand_gate_design_zynq_ultra_ps_e_0_0_vip_wrapper.v" \

vcom -work lib_cdc_v1_0_2 -93 \
"../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/ef1e/hdl/lib_cdc_v1_0_rfs.vhd" \

vcom -work proc_sys_reset_v5_0_13 -93 \
"../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/8842/hdl/proc_sys_reset_v5_0_vh_rfs.vhd" \

vcom -work xil_defaultlib -93 \
"../../../bd/nand_gate_design/ip/nand_gate_design_proc_sys_reset_0_0/sim/nand_gate_design_proc_sys_reset_0_0.vhd" \

vcom -work axi_lite_ipif_v3_0_4 -93 \
"../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/66ea/hdl/axi_lite_ipif_v3_0_vh_rfs.vhd" \

vcom -work interrupt_control_v3_1_4 -93 \
"../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/a040/hdl/interrupt_control_v3_1_vh_rfs.vhd" \

vcom -work axi_gpio_v2_0_28 -93 \
"../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/3ed9/hdl/axi_gpio_v2_0_vh_rfs.vhd" \

vcom -work xil_defaultlib -93 \
"../../../bd/nand_gate_design/ip/nand_gate_design_axi_gpio_0_0/sim/nand_gate_design_axi_gpio_0_0.vhd" \
"../../../bd/nand_gate_design/ip/nand_gate_design_axi_gpio_1_0/sim/nand_gate_design_axi_gpio_1_0.vhd" \

vlog -work xil_defaultlib  -v2k5 "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/ec67/hdl" "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/8cdf/hdl" "+incdir+N:/Xilinx/Vivado/2022.1/data/xilinx_vip/include" \
"../../../bd/nand_gate_design/ip/nand_gate_design_nand_gate_0_0/sim/nand_gate_design_nand_gate_0_0.v" \

vlog -work generic_baseblocks_v2_1_0  -v2k5 "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/ec67/hdl" "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/8cdf/hdl" "+incdir+N:/Xilinx/Vivado/2022.1/data/xilinx_vip/include" \
"../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/b752/hdl/generic_baseblocks_v2_1_vl_rfs.v" \

vlog -work axi_register_slice_v2_1_26  -v2k5 "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/ec67/hdl" "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/8cdf/hdl" "+incdir+N:/Xilinx/Vivado/2022.1/data/xilinx_vip/include" \
"../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/0a3f/hdl/axi_register_slice_v2_1_vl_rfs.v" \

vlog -work fifo_generator_v13_2_7  -v2k5 "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/ec67/hdl" "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/8cdf/hdl" "+incdir+N:/Xilinx/Vivado/2022.1/data/xilinx_vip/include" \
"../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/83df/simulation/fifo_generator_vlog_beh.v" \

vcom -work fifo_generator_v13_2_7 -93 \
"../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/83df/hdl/fifo_generator_v13_2_rfs.vhd" \

vlog -work fifo_generator_v13_2_7  -v2k5 "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/ec67/hdl" "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/8cdf/hdl" "+incdir+N:/Xilinx/Vivado/2022.1/data/xilinx_vip/include" \
"../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/83df/hdl/fifo_generator_v13_2_rfs.v" \

vlog -work axi_data_fifo_v2_1_25  -v2k5 "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/ec67/hdl" "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/8cdf/hdl" "+incdir+N:/Xilinx/Vivado/2022.1/data/xilinx_vip/include" \
"../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/5390/hdl/axi_data_fifo_v2_1_vl_rfs.v" \

vlog -work axi_crossbar_v2_1_27  -v2k5 "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/ec67/hdl" "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/8cdf/hdl" "+incdir+N:/Xilinx/Vivado/2022.1/data/xilinx_vip/include" \
"../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/3fa0/hdl/axi_crossbar_v2_1_vl_rfs.v" \

vlog -work xil_defaultlib  -v2k5 "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/ec67/hdl" "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/8cdf/hdl" "+incdir+N:/Xilinx/Vivado/2022.1/data/xilinx_vip/include" \
"../../../bd/nand_gate_design/ip/nand_gate_design_xbar_0/sim/nand_gate_design_xbar_0.v" \

vlog -work axi_protocol_converter_v2_1_26  -v2k5 "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/ec67/hdl" "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/8cdf/hdl" "+incdir+N:/Xilinx/Vivado/2022.1/data/xilinx_vip/include" \
"../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/90c8/hdl/axi_protocol_converter_v2_1_vl_rfs.v" \

vlog -work axi_clock_converter_v2_1_25  -v2k5 "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/ec67/hdl" "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/8cdf/hdl" "+incdir+N:/Xilinx/Vivado/2022.1/data/xilinx_vip/include" \
"../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/e893/hdl/axi_clock_converter_v2_1_vl_rfs.v" \

vlog -work blk_mem_gen_v8_4_5  -v2k5 "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/ec67/hdl" "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/8cdf/hdl" "+incdir+N:/Xilinx/Vivado/2022.1/data/xilinx_vip/include" \
"../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/25a8/simulation/blk_mem_gen_v8_4.v" \

vlog -work axi_dwidth_converter_v2_1_26  -v2k5 "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/ec67/hdl" "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/8cdf/hdl" "+incdir+N:/Xilinx/Vivado/2022.1/data/xilinx_vip/include" \
"../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/b3c7/hdl/axi_dwidth_converter_v2_1_vl_rfs.v" \

vlog -work xil_defaultlib  -v2k5 "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/ec67/hdl" "+incdir+../../../../kv260_nand_gate.gen/sources_1/bd/nand_gate_design/ipshared/8cdf/hdl" "+incdir+N:/Xilinx/Vivado/2022.1/data/xilinx_vip/include" \
"../../../bd/nand_gate_design/ip/nand_gate_design_auto_ds_0/sim/nand_gate_design_auto_ds_0.v" \
"../../../bd/nand_gate_design/ip/nand_gate_design_auto_pc_0/sim/nand_gate_design_auto_pc_0.v" \
"../../../bd/nand_gate_design/ip/nand_gate_design_auto_ds_1/sim/nand_gate_design_auto_ds_1.v" \
"../../../bd/nand_gate_design/ip/nand_gate_design_auto_pc_1/sim/nand_gate_design_auto_pc_1.v" \
"../../../bd/nand_gate_design/sim/nand_gate_design.v" \

vlog -work xil_defaultlib \
"glbl.v"

