library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity nand_gate is
    Port (
        in_pins : in STD_LOGIC_VECTOR(1 downto 0);
        out_pin : out STD_LOGIC_VECTOR(0 downto 0)
    );
end nand_gate;

architecture Behavioral of nand_gate is
begin
    out_pin(0) <= NOT (in_pins(0) AND in_pins(1));
end Behavioral;