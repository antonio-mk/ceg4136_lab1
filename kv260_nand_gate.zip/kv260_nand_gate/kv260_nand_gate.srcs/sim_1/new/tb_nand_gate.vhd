library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_nand_gate is
end tb_nand_gate;

architecture sim of tb_nand_gate is
    signal in_pins : STD_LOGIC_VECTOR(1 downto 0) := "00";
    signal out_pin : STD_LOGIC_VECTOR(0 downto 0);
begin
-- Instantiate the Unit Under Test (UUT)
    uut : entity work.nand_gate
stimulus : process
y
port map ( in_pins => in_pins, out_pin => out_pin );-- Drive every input combination and check the expected NAND output
type pattern is record
a, b : STD_LOGIC;
: STD_LOGIC;-- expected NAND(a,b)
end record;
type pattern_array is array (natural range <>) of pattern;
constant patterns : pattern_array := (
('0','0','1'),
('0','1','1'),
('1','0','1'),
('1','1','0') );
begin
for i in patterns'range loop
29
in_pins(0) <= patterns(i).a;
Kria KV260 Platform 26
2026
CEG 4136 - Computer Architecture III
Lab 1, Week 1
30
31
in_pins(1) <= patterns(i).b;
wait for 20 ns;
32
assert out_pin(0) = patterns(i).y
33
report "MISMATCH: A=" & std_logic'image(patterns(i).a)
&
34
" B=" & std_logic'image(patterns(i).b)
35
severity error;
36
end loop;
37
report "NAND test bench completed: all 4 combinations checked."
38
severity note;
39
wait;-- stop the simulation
40
end process;
41 end sim;